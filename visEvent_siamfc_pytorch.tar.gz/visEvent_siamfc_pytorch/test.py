from __future__ import absolute_import

import os
import sys 
sys.path.insert(0,'./')
from got10k.experiments import *

from siamfc import TrackerSiamFC


if __name__ == '__main__':
    net_path = 'pretrained/siamfc_alexnet_e50.pth'
    tracker = TrackerSiamFC(net_path=net_path)

    # root_dir = os.path.expanduser('~/data/OTB')
    # e = ExperimentOTB(root_dir, version=2015)

    root_dir = os.path.expanduser('/home/wangxiao/Documents/rgb_event_tracking_benchmark/visEvent_dataset')
    e = ExperimentNfS(root_dir)
    e.run(tracker)
    # e.report([tracker.name])
