from __future__ import absolute_import, print_function

import os
import glob
import numpy as np
import six


class NfSEvent(object):

    def __init__(self, root_dir, subset='test', return_meta=False):
        super(NfSEvent, self).__init__()

        # import pdb 
        # pdb.set_trace() 
        assert subset in ['train', 'val', 'test'], 'Unknown subset.'

        self.root_dir = root_dir
        self.subset = subset
        self.return_meta = False if subset == 'test' else return_meta
        # self._check_integrity(root_dir, subset)

        # list_file = os.path.join(root_dir, subset, 'list.txt')
        # with open(list_file, 'r') as f:
        #     self.seq_names = f.read().strip().split('\n')

        

        self.seq_names = os.listdir(root_dir+'/'+subset+'/') 
        self.seq_dirs_RGB   = [os.path.join(root_dir, subset, s, 'vis_imgs') for s in self.seq_names]
        self.seq_dirs_Event = [os.path.join(root_dir, subset, s, 'event_imgs') for s in self.seq_names]
        self.anno_files     = [os.path.join(root_dir, subset, s, 'groundtruth.txt') for s in self.seq_names] 
    

        # print("seq_dirs_RGB: ", self.seq_dirs_RGB)  
        # print("seq_dirs_Event: ", self.seq_dirs_Event)  


    def __getitem__(self, index):
        r"""        
        Args:
            index (integer or string): Index or name of a sequence.
        
        Returns:
            tuple: (img_files, anno) if ``return_meta`` is False, otherwise
                (img_files, anno, meta), where ``img_files`` is a list of
                file names, ``anno`` is a N x 4 (rectangles) numpy array, while
                ``meta`` is a dict contains meta information about the sequence.
        """
        if isinstance(index, six.string_types):
            if not index in self.seq_names:
                raise Exception('Sequence {} not found.'.format(index))
            index = self.seq_names.index(index)

        img_files_RGB   = sorted(glob.glob(os.path.join(self.seq_dirs_RGB[index], '*.bmp')))
        img_files_Event = sorted(glob.glob(os.path.join(self.seq_dirs_Event[index], '*.bmp')))
        anno = np.loadtxt(self.anno_files[index], delimiter=',')



        # #### check the number of seq and annotations 
        # if self.subset == 'test' and anno.ndim == 1:
        #     assert len(anno) == 4
        #     anno = anno[np.newaxis, :]
        # else:
        #     assert len(img_files) == len(anno)

        if self.return_meta:
            meta = self._fetch_meta(self.seq_dirs[index])
            return img_files_RGB, img_files_Event, anno, meta
        else:
            return img_files_RGB, img_files_Event, anno

    def __len__(self):
        return len(self.seq_names)

    def _check_integrity(self, root_dir, subset):
        assert subset in ['train', 'val', 'test']
        list_file = os.path.join(root_dir, subset, 'list.txt')

        if os.path.isfile(list_file):
            with open(list_file, 'r') as f:
                seq_names = f.read().strip().split('\n')
            
            # check each sequence folder
            for seq_name in seq_names:
                seq_dir = os.path.join(root_dir, subset, seq_name)
                if not os.path.isdir(seq_dir):
                    print('Warning: sequence %s not exists.' % seq_name)
        else:
            # dataset not exists
            raise Exception('Dataset not found or corrupted.')

    def _fetch_meta(self, seq_dir):
        # meta information
        meta_file = os.path.join(seq_dir, 'meta_info.ini')
        with open(meta_file) as f:
            meta = f.read().strip().split('\n')[1:]
        meta = [line.split(': ') for line in meta]
        meta = {line[0]: line[1] for line in meta}

        # attributes
        attributes = ['cover', 'absence', 'cut_by_image']
        for att in attributes:
            meta[att] = np.loadtxt(os.path.join(seq_dir, att + '.label'))

        return meta
