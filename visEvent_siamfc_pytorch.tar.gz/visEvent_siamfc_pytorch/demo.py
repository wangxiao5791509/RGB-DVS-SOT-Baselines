from __future__ import absolute_import

import os
import glob
import numpy as np

from siamfc import TrackerSiamFC


if __name__ == '__main__':

    videoName = 'GOT-10k_Test_000005'
    print("==>> videoName: ", videoName) 
    seq_dir = os.path.expanduser('/home/wangxiao/Documents/rgb_event_tracking_benchmark/visEvent_siamfc_pytorch/data/GOT10k_visEvent/test/' + videoName + '/')
    img_files_rgb = sorted(glob.glob(seq_dir + 'vis_IMGs/*.jpg'))
    img_files_event = sorted(glob.glob(seq_dir + 'event_IMGs/*.png'))
    anno = np.loadtxt(seq_dir + 'groundtruth_346260.txt', delimiter=',')
    
    net_path = '/home/wangxiao/Documents/rgb_event_tracking_benchmark/visEvent_siamfc_pytorch/pretrained/siamfc_alexnet_e50.pth'
    tracker = TrackerSiamFC(net_path=net_path)
    # tracker.track(img_files_rgb, img_files_event, anno[0], visualize=True)
    tracker.track(img_files_rgb, img_files_event, anno, visualize=True)


